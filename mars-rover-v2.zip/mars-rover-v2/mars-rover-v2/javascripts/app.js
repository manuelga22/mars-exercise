// Rover Object Goes Here
// ======================
var rover={
  direction:"N",
  x:0,
  y:0,
  travelLog: []
}
// ======================
function turnLeft(rover){
  console.log("turnLeft was called!");
  if(rover.direction =="N"){rover.direction="W";}
  else if(rover.direction=="W"){rover.direction="S";}
  else if(rover.direction=="S"){rover.direction="E";}
  else {rover.direction="N";}

  console.log("rover is now facing "+ rover["direction"]);
}

function turnRight(rover){
  console.log("turnRight was called!");
  if(rover.direction =="N"){rover.direction="E";}
  else if(rover.direction=="W"){rover.direction="N";}
  else if(rover.direction=="S"){rover.direction="W";}
  else {rover.direction="S";}

  console.log("rover is now facing "+ rover.direction);
}

function moveForward(rover){
  console.log("moveForward was called");
  if(rover.direction == "W") rover.x -=1;
  if(rover.direction == "N") rover.y -=1;
  if(rover.direction == "S") rover.y +=1;
  if(rover.direction == "E") rover.x +=1;
  rover.travelLog.push("["+rover.x +","+ rover.y+"]");
  console.log("Rover's current position is ["+ rover.x + ","+rover.y+"]");
}
function command(string){
   for(var a=0;a<string.length;a++){
      if(string.substring(a,a+1)=="f")moveForward(rover.direction);
      else if (string.substring(a,a+1)=="r")turnRight(rover.direction);
      else if (string.substring(a,a+1)=="l")turnLeft(rover.direction);
   }
}
